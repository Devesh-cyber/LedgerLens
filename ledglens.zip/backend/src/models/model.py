from datetime import date, datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional
from sqlmodel import Column, Field, JSON, Relationship, SQLModel

class InvoiceStatus(str, Enum):
    UPLOADED = "UPLOADED"
    PROCESSING = "PROCESSING"
    NEEDS_REVIEW = "NEEDS_REVIEW"
    VALID = "VALID"
    APPROVED = "APPROVED"

class Vendor(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    raw_name: str = Field(index=True)
    canonical_name: Optional[str] = Field(default=None, index=True)
    tax_id: Optional[str] = Field(default=None)

    invoices: List["Invoice"] = Relationship(back_populates="vendor")

class Invoice(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    vendor_id: Optional[int] = Field(default=None, foreign_key="vendor.id")

    invoice_number: Optional[str] = Field(default=None, index=True)
    invoice_date: Optional[date] = Field(default=None)
    due_date: Optional[date] = Field(default=None)
    
    subtotal: Optional[float] = Field(default=None)
    tax_amount: Optional[float] = Field(default=None)
    total_amount: Optional[float] = Field(default=None)
    
    status: InvoiceStatus = Field(default=InvoiceStatus.UPLOADED, index=True)
    file_path: str = Field(default="pending")
    
    confidence_scores: Dict[str, Any] = Field(default_factory=dict, sa_column=Column(JSON))
    validation_errors: List[str] = Field(default_factory=list, sa_column=Column(JSON))
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    vendor: Optional[Vendor] = Relationship(back_populates="invoices")
    line_items: List["LineItem"] = Relationship(back_populates="invoice", cascade_delete=True)

class LineItem(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    invoice_id: int = Field(foreign_key="invoice.id")

    description: str
    quantity: float = Field(default=1.0)
    unit_price: float = Field(default=0.0)
    line_total: float = Field(default=0.0)

    invoice: Invoice = Relationship(back_populates="line_items")



